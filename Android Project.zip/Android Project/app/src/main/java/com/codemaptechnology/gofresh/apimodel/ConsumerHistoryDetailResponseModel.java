package com.codemaptechnology.gofresh.apimodel;

import java.util.ArrayList;

/**
 * Created by satishmarkad on 12/04/16.
 */
public class ConsumerHistoryDetailResponseModel extends ResponseModel{

    private static ConsumerHistoryDetailResponseModel INSTANCE;
    public ArrayList<Orderdesc> orderdesc;

    public static ConsumerHistoryDetailResponseModel onGetInsatance(){

        if(INSTANCE==null){
            INSTANCE=new ConsumerHistoryDetailResponseModel();
        }
        return INSTANCE;
    }

    public class Orderdesc
    {
        public ArrayList<Orddetails> orddetails;

        public String orddatetime;

        public String ordstatus;

        public String ordtextid;

        public String ordertotal;

    }

    public class Orddetails
    {
        public String ordvegprice;

        public String ordtotal;

        public String vegnameeng;

        public String ordqty;


    }

    public void onSetResponseObject(ConsumerHistoryDetailResponseModel resp){

        INSTANCE=resp;
    }

}
