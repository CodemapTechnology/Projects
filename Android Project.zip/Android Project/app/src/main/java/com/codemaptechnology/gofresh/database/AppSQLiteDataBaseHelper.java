package com.codemaptechnology.gofresh.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by satishmarkad on 12/04/16.
 */
public class AppSQLiteDataBaseHelper extends SQLiteOpenHelper {
    public AppSQLiteDataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "VegeDatabase";
    private static final String DATABASE_TABLE="VegetableDetails";
    private static final String COL_ID="Id";
    private static final String COL_VEGEID="VegetableID";
    private static final String COL_IMAGEPATH="ImagePath";

    public AppSQLiteDataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub

        String lCreateTable="CREATE TABLE "+DATABASE_TABLE+"("+COL_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"
                +COL_VEGEID+" TEXT,"+COL_IMAGEPATH+" TEXT"+")";
        db.execSQL(lCreateTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub

    }

    public void onInsertPeopleDetails(String vegId,String imgpath){
        //TODO Insert Data in Table
        SQLiteDatabase lDB=this.getWritableDatabase();
        ContentValues lContentValue=new ContentValues();
        lContentValue.put(COL_VEGEID, vegId);
        lContentValue.put(COL_IMAGEPATH,imgpath);
        lDB.insert(DATABASE_TABLE, null,lContentValue);
        Log.e("Insert Data",""+vegId);
        lDB=null;
    }



    public String onGetVegetableDetailDataBase(String id){
        //TODO Retrive All Data From TablEmployeeContactDetailWrappere
        SQLiteDatabase lDB=this.getReadableDatabase();
        String lQuery="Select * From "+DATABASE_TABLE +" Where "+COL_VEGEID+"='"+id+"'";
        Log.e("lQuerry",lQuery);
        Cursor lCursor=lDB.rawQuery(lQuery, null);
        String url="";
        if(lCursor.moveToFirst()){

            do{
                url=lCursor.getString(2);

            }while(lCursor.moveToNext());

        }
        lDB.close();
        return url;

    }




    public int onGetTableRowCount(){
        int lCount;
        SQLiteDatabase lDB = this.getReadableDatabase();
        Cursor lCursor=lDB.rawQuery("Select * From "+DATABASE_TABLE, null);
        lCount=lCursor.getCount();
        lCursor.close();
        lDB.close();
        return lCount;
    }
    public void onDeleteDataBase(){
        //TODO Delete All Reocord From Table
        SQLiteDatabase lDB=this.getWritableDatabase();
        lDB.delete(DATABASE_TABLE, null,null);
        lDB.close();

    }
}
