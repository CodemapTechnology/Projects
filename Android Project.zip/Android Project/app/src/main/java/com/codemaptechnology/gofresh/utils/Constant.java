package com.codemaptechnology.gofresh.utils;

/**
 * Created by satishmarkad on 20/01/16.
 */
public class Constant {


    public static String SERVER_URL="http://290px.com/farms/";
    public static String GETSTOCKVEGETABLE="getstockedvegiJSON.php";
    public static String GETPROMODISCOUNT="getpromo.php?";
    public static String SETMESSAGE="writemsg.php?";
    public static String SETPLACEORDER="placeorder.php";
    public static String GETORDERHISTORY="customrorderhist.php?";

}
