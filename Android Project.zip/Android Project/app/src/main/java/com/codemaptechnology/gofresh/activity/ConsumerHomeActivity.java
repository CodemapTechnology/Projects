package com.codemaptechnology.gofresh.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.codemaptechnology.gofresh.apimodel.ConsumerVegtableDetailResponseModel;
import com.codemaptechnology.gofresh.application.VegetableApplicationContext;
import com.codemaptechnology.gofresh.http.JsonRequestClass;
import com.codemaptechnology.gofresh.http.ResponseListner;
import com.codemaptechnology.gofresh.utils.AlertDialogs;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.adapter.ConsumerOrderListAdapter;
import com.codemaptechnology.gofresh.apimodel.RequestModel;
import com.codemaptechnology.gofresh.database.AppSQLiteDataBaseHelper;
import com.codemaptechnology.gofresh.javabean.ConsumerOrderTagBean;
import com.codemaptechnology.gofresh.utils.Constant;
import com.codemaptechnology.gofresh.utils.NetworkConnectivity;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.UUID;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class ConsumerHomeActivity extends AppCompatActivity implements ResponseListner {

    @Bind(R.id.txt_totalamount)
    TextView txt_TotalBalance;
    @Bind(R.id.recyclerview_orderlist)
    RecyclerView recyclerView_OrderList;
    public static ArrayList<ConsumerOrderTagBean> mConsumerOrderList;
    ArrayList<ConsumerVegtableDetailResponseModel.VegDetailWrapper> mVegeDetailList;
    private AlertDialogs mAlertDialogs;

    protected void onCreate(Bundle onSaveInstanceState){
        super.onCreate(onSaveInstanceState);
        setContentView(R.layout.activity_consumerorder);
        ButterKnife.bind(this);
        init();

    }

    private void init() {
        mAlertDialogs=AlertDialogs.getInstance();
        mConsumerOrderList=new ArrayList<ConsumerOrderTagBean>();
        recyclerView_OrderList.setHasFixedSize(true);
        recyclerView_OrderList.setLayoutManager(new LinearLayoutManager(ConsumerHomeActivity.this));

       // recyclerView_OrderList.bringToFront()
        if(NetworkConnectivity.isOnline()) {
            onSendRequestToServer();
        }else{
            mAlertDialogs.onShowToastNotification(getResources().getString(R.string.error_netconnection));
        }
    }

    private void onSendRequestToServer() {
        RequestModel lRequest=new RequestModel();
        lRequest.setAPImethod(Constant.GETSTOCKVEGETABLE);
        new JsonRequestClass(this).onJsonObjReq(this, lRequest);
    }

    @OnClick(R.id.btn_order)
    public void btn_order(View v){

        if(mConsumerOrderList.size()>0) {
            Intent intent = new Intent(ConsumerHomeActivity.this, ConsumerOrderActivity.class);
            intent.putExtra("TOTALAMOUNT", Double.parseDouble(txt_TotalBalance.getText().toString()));
            startActivity(intent);
        }else{
            AlertDialogs.getInstance().onShowToastNotification(getResources().getString(R.string.error_placeorder));
        }
    }
    @OnClick(R.id.footer_help)
    public void footer_help(View v){

        if(NetworkConnectivity.isOnline()) {
            Intent intent=new Intent(ConsumerHomeActivity.this,WriteUsHelpActivity.class);
            intent.putExtra("ISHELP", true);
            startActivity(intent);
        }else{
            mAlertDialogs.onShowToastNotification(getResources().getString(R.string.error_netconnection));
        }
    }
    @OnClick(R.id.footer_writeus)
    public void footer_writeus(View v){
        if(NetworkConnectivity.isOnline()) {
            if(VegetableApplicationContext.onGETUserEmail().length()>0) {
                startActivity(new Intent(ConsumerHomeActivity.this, WriteUsHelpActivity.class));
            }else{
                mAlertDialogs.onShowToastNotification(getResources().getString(R.string.error_usernotregistor));
            }

        }else{
            mAlertDialogs.onShowToastNotification(getResources().getString(R.string.error_netconnection));
        }
    }

    @OnClick(R.id.footer_history)
    public void footer_history(View v){

        if(NetworkConnectivity.isOnline()) {
            if(VegetableApplicationContext.onGETUserEmail().length()>0) {
                startActivity(new Intent(ConsumerHomeActivity.this, ConsumerOrderHistoryActivity.class));
            }else{
                mAlertDialogs.onShowToastNotification(getResources().getString(R.string.error_usernotregistor));
            }
        }else{
            mAlertDialogs.onShowToastNotification(getResources().getString(R.string.error_netconnection));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mConsumerOrderList.size()==0&&mVegeDetailList!=null) {
            for(int i=0;i<mVegeDetailList.size();i++){
                mVegeDetailList.get(i).isSelected=false;
            }
            onSetAdapters(mVegeDetailList);
            txt_TotalBalance.setText("0.00");
        }
    }

    @Override
    public void onGetResponse(String res) {

        Log.e("Response",res);

        ConsumerVegtableDetailResponseModel lResponse=new ConsumerVegtableDetailResponseModel();

        lResponse=new Gson().fromJson(res,lResponse.getClass());
//        if(lResponse) {
//
//        }else {
           new VegetableImageDownloadTask(lResponse.vegidesc).execute();
            Log.e("Data", "" + lResponse.vegidesc.get(0).vegid);
       // }
    }

    private class VegetableImageDownloadTask extends
            AsyncTask<String, String, String> {
        AppSQLiteDataBaseHelper lDataBase;
        AlertDialogs mDialog;
        public VegetableImageDownloadTask(
                ArrayList<ConsumerVegtableDetailResponseModel.VegDetailWrapper> result) {
            // TODO Auto-generated constructor stub
            mVegeDetailList = result;
            mDialog=AlertDialogs.getInstance();
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            mDialog.onShowProgressDialog(ConsumerHomeActivity.this, true);
            lDataBase = VegetableApplicationContext.getDataBase();

        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            if (NetworkConnectivity.isOnline()) {


                for (int i = 0; i < mVegeDetailList.size(); i++) {

                    String lVegId=mVegeDetailList.get(i).vegid;
                    String lUrl=lDataBase.onGetVegetableDetailDataBase(lVegId);

                    if(lUrl.length()==0) {
                        lUrl = onImageDownload(mVegeDetailList.get(i).vegphoto);
                        lDataBase.onInsertPeopleDetails(lVegId,lUrl);
                    }
                    Log.e("URL",""+lUrl);
                    mVegeDetailList.get(i).vegphoto=lUrl;

                }

            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            mDialog.onShowProgressDialog(ConsumerHomeActivity.this, false);
            onSetAdapters(mVegeDetailList);
        }

    }

    private void onSetAdapters(ArrayList<ConsumerVegtableDetailResponseModel.VegDetailWrapper> mVegeDetailList) {

        ConsumerOrderListAdapter  mAdapter=new ConsumerOrderListAdapter(ConsumerHomeActivity.this,mVegeDetailList);
        recyclerView_OrderList.setAdapter(mAdapter);
    }

    private String onImageDownload(String url) {
        // TODO Download Image from Server
        File lFile = null;
        try {

            String lFilePath=onGetOrDeleteFilepath(false);
            if(lFilePath!=null){
                lFile = new File(lFilePath);

                FileOutputStream lFileOutputStream = new FileOutputStream(lFile);

                InputStream lInputStream = new java.net.URL(url).openStream();

                byte[] lBuffer = new byte[1024];
                int lBufferLength = 0;
                while ((lBufferLength = lInputStream.read(lBuffer)) > 0) {

                    lFileOutputStream.write(lBuffer, 0, lBufferLength);

                }
                lFileOutputStream.close();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "" + lFile.getPath();
    }
    private String onGetOrDeleteFilepath(boolean isDelete) {
        // TODO Genrate Unique URL or Delete File
        File lAPPDirectory = null;
        try{
           // lAPPDirectory = new File(
            //        Environment.getExternalStorageDirectory()+"/."+getString(R.string.app_name),getString(R.string.txt_directory));
            lAPPDirectory = new File(this.getExternalFilesDir("").getAbsoluteFile(),getString(R.string.app_name)); //Creating an internal dir;

            if (!lAPPDirectory.exists()) {
                lAPPDirectory.mkdirs();
            }
            if (isDelete) {

                for (File childFile : lAPPDirectory.listFiles()) {
                    childFile.delete();
                }

            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return lAPPDirectory + "/" + UUID.randomUUID() + ".png";

    }


    public void onSetTotalAmount(String price){
        double lTotoal=Double.parseDouble(txt_TotalBalance.getText().toString())+Double.parseDouble(price);
        txt_TotalBalance.setText(""+lTotoal);

    }
    public Bitmap getResizedBitmap(String url, int maxSize) {
        Bitmap image= BitmapFactory.decodeFile(url);
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }
}
