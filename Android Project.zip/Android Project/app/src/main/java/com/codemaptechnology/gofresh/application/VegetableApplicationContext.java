package com.codemaptechnology.gofresh.application;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.codemaptechnology.gofresh.database.AppSQLiteDataBaseHelper;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

/**
 * Created by satishmarkad on 28/03/16.
 */
public class VegetableApplicationContext extends Application {

    private static Context gContext;
    private static SharedPreferences mSharedPreferences;
    private static AppSQLiteDataBaseHelper INSTANSE;



    public void onCreate(){
        super.onCreate();

        gContext=getApplicationContext();
        INSTANSE=new AppSQLiteDataBaseHelper(getContext());
        mSharedPreferences = gContext
                .getSharedPreferences("VegetableApp", MODE_PRIVATE);


        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheOnDisc(true).cacheInMemory(true)
                .imageScaleType(ImageScaleType.EXACTLY)
                .displayer(new FadeInBitmapDisplayer(300)).build();

        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
                getApplicationContext())
                .defaultDisplayImageOptions(defaultOptions)
                .memoryCache(new WeakMemoryCache())
                .discCacheSize(100 * 1024 * 1024).build();
        ImageLoader.getInstance().init(config);
    }

    public static Context getContext() {
        return gContext;
    }
    public static void onSaveUserDetail(String address,String email,String num) {

        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString("ADDRESS", address);
        editor.putString("EMAIL", email);
        editor.putString("NUMBER",num);
        editor.commit();
    }


    public static float onGetAvilableBalance(){
        return mSharedPreferences.getFloat("AvilableBalance", 0);
    }

    public static AppSQLiteDataBaseHelper getDataBase() {
        return INSTANSE;
    }

    public static String onGETUserAddress(){
        return mSharedPreferences.getString("ADDRESS","");
    }
    public static String onGETUserEmail(){
        return mSharedPreferences.getString("EMAIL","");
    }public static String onGETUserNumber(){
        return mSharedPreferences.getString("NUMBER","");
    }
}

