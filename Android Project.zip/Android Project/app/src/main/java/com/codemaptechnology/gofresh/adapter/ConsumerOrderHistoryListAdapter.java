package com.codemaptechnology.gofresh.adapter;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.codemaptechnology.gofresh.activity.ConsumerOrderDetailHistoryActivity;
import com.codemaptechnology.gofresh.activity.ConsumerOrderHistoryActivity;
import com.codemaptechnology.gofresh.apimodel.ConsumerHistoryDetailResponseModel;
import com.codemaptechnology.gofresh.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by satishmarkad on 29/03/16.
 */
public class ConsumerOrderHistoryListAdapter extends RecyclerView.Adapter<ConsumerOrderHistoryListAdapter.ViewHolder> {

    private ArrayList<ConsumerHistoryDetailResponseModel.Orderdesc>  mVegeDetailList;
    private ConsumerOrderHistoryActivity mConsumerHomeActivity;

    public ConsumerOrderHistoryListAdapter(ConsumerOrderHistoryActivity consumerHomeActivity, ArrayList<ConsumerHistoryDetailResponseModel.Orderdesc> veglist) {
          mVegeDetailList=veglist;
         mConsumerHomeActivity=consumerHomeActivity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_historyorderlistitem, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.txt_VegTitle.setText(mVegeDetailList.get(position).ordtextid);
        holder.txt_VegTotalAmount.setText(mVegeDetailList.get(position).ordertotal);
        holder.txt_OrderDate.setText(onConvertDateFormat(mVegeDetailList.get(position).orddatetime));
        holder.mLayout.setTag(""+position);
        holder.mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int lPosti= Integer.parseInt((String) v.getTag());
                Intent i=new Intent(mConsumerHomeActivity, ConsumerOrderDetailHistoryActivity.class);
                i.putExtra("POSITION",lPosti);
                mConsumerHomeActivity.startActivity(i);
            }
        });

 }

    private String onConvertDateFormat(String orddatetime) {

        String lDate="";
        try {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date d = df.parse(orddatetime);
            df = new SimpleDateFormat("dd MMM");
            lDate=df.format(d);
        }catch (Exception e){}
        return lDate;
    }

    @Override
    public int getItemCount() {
        return mVegeDetailList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        public TextView txt_VegTitle,txt_VegTotalAmount,txt_OrderDate;
        public RelativeLayout mLayout;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mLayout= (RelativeLayout) view.findViewById(R.id.layout_historyorder);
            txt_VegTitle=(TextView)view.findViewById(R.id.txt_cvegetitle);
            txt_VegTotalAmount=(TextView)view.findViewById(R.id.txt_cvegeamount);
            txt_OrderDate=(TextView)view.findViewById(R.id.txt_cvegedate);

        }

    }
}
