package com.codemaptechnology.gofresh.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.codemaptechnology.gofresh.apimodel.ConsumerHistoryDetailResponseModel;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.activity.ConsumerOrderDetailHistoryActivity;

import java.util.ArrayList;

/**
 * Created by satishmarkad on 29/03/16.
 */
public class ConsumerOrderDetailHistoryListAdapter extends RecyclerView.Adapter<ConsumerOrderDetailHistoryListAdapter.ViewHolder> {

    private ArrayList<ConsumerHistoryDetailResponseModel.Orddetails>  mVegeDetailList;
    private ConsumerOrderDetailHistoryActivity mConsumerHomeActivity;

    public ConsumerOrderDetailHistoryListAdapter(ConsumerOrderDetailHistoryActivity consumerHomeActivity, ArrayList<ConsumerHistoryDetailResponseModel.Orddetails> veglist) {
          mVegeDetailList=veglist;
         mConsumerHomeActivity=consumerHomeActivity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_detailhistoryorderlistitem, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem=mVegeDetailList.get(position);
        holder.txt_VegTitle.setText(holder.mItem.vegnameeng);
        String lPrice=holder.mItem.ordvegprice;
        holder.txt_VegPrice.setText(lPrice);
       // holder.img_VegImage.setImageBitmap(BitmapFactory.decodeFile(holder.mItem.vegphoto));
        holder.txt_VegPriceQuan.setText(lPrice + " x  "+holder.mItem.ordqty+" = " + holder.mItem.ordtotal);
 }



    @Override
    public int getItemCount() {
        return mVegeDetailList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        public ConsumerHistoryDetailResponseModel.Orddetails mItem;
        public TextView txt_VegTitle,txt_VegQuantity,txt_VegPrice,txt_VegPerKG,txt_VegPriceQuan,txt_VegTotalAmount,txt_OrderDate;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            txt_VegTitle=(TextView)view.findViewById(R.id.txt_cvegetitle);
            txt_VegQuantity=(TextView)view.findViewById(R.id.txt_cvegequantity);
            txt_VegPrice=(TextView)view.findViewById(R.id.txt_cvegeamount);
            txt_VegPerKG=(TextView)view.findViewById(R.id.txt_cvegechangequantity);
            txt_VegPriceQuan=(TextView)view.findViewById(R.id.txt_cvegselectquantity);
            txt_VegTotalAmount=(TextView)view.findViewById(R.id.txt_cvegetotalamount);
            txt_OrderDate=(TextView)view.findViewById(R.id.txt_cvegedate);

        }

    }
}
