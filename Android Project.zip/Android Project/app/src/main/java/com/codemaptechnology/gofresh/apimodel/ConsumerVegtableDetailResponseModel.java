package com.codemaptechnology.gofresh.apimodel;

import java.util.ArrayList;

/**
 * Created by satishmarkad on 12/04/16.
 */
public class ConsumerVegtableDetailResponseModel {

    public ArrayList<VegDetailWrapper>vegidesc;


    public class VegDetailWrapper{

        public String veginstock;

        public String vegphoto;

        public String vegunit;

        public String vegdatetime;

        public String vegid;

        public String vegnameeng;

        public String vegprice;

        public boolean isSelected;
        public String custquanity;
        public String custtotal;

        
    }
}
