package com.codemaptechnology.gofresh.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.activity.ConsumerHomeActivity;
import com.codemaptechnology.gofresh.apimodel.ConsumerVegtableDetailResponseModel;
import com.codemaptechnology.gofresh.javabean.ConsumerOrderTagBean;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;



/**
 * Created by satishmarkad on 29/03/16.
 */
public class ConsumerOrderListAdapter extends RecyclerView.Adapter<ConsumerOrderListAdapter.ViewHolder> {

    private ArrayList<ConsumerVegtableDetailResponseModel.VegDetailWrapper> mVegeDetailList;
    private ConsumerHomeActivity mConsumerHomeActivity;
    private ImageLoader mImageLoader;
    private DisplayImageOptions mOptions;
    public ConsumerOrderListAdapter(ConsumerHomeActivity consumerHomeActivity, ArrayList<ConsumerVegtableDetailResponseModel.VegDetailWrapper> veglist) {
          mVegeDetailList=veglist;
         mConsumerHomeActivity=consumerHomeActivity;
         mImageLoader= ImageLoader.getInstance();
        mOptions = new DisplayImageOptions.Builder().cacheInMemory(true)
                .cacheOnDisc(true).resetViewBeforeLoading(true).build();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_orderlistitem, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem=mVegeDetailList.get(position);
        holder.txt_VegTitle.setText(holder.mItem.vegnameeng);
        String lPrice=holder.mItem.vegprice;
        holder.txt_VegPrice.setText(lPrice);

        mImageLoader.displayImage("file://"+ holder.mItem.vegphoto,holder.img_VegImage);
        holder.btn_VegPositive.setTag(holder.mItem.veginstock);


        holder.btn_VegNegative.setTag(lPrice);
        ConsumerOrderTagBean lObje=new ConsumerOrderTagBean();
        lObje.QuantityView=holder.txt_VegPriceQuan;
        lObje.VegId=holder.mItem.vegid;
        lObje.SelectedPosition=position;
        holder.btn_VegAddToCard.setTag(lObje);
        holder.txt_VegPriceQuan.setText("");
        if(holder.mItem.isSelected){
            holder.btn_VegAddToCard.setBackgroundResource(R.drawable.style_button_darkgray);
            holder.txt_VegPriceQuan.setText(lPrice + " x " + holder.mItem.custquanity + "=");
            holder.txt_VegTotalAmount.setText(""+holder.mItem.custtotal);
            holder.txt_VegPerKG.setText(holder.mItem.custquanity);
            holder.btn_VegAddToCard.setEnabled(false);
        }else {

            holder.btn_VegAddToCard.setBackgroundResource(R.drawable.style_button_lightgray);
            holder.btn_VegAddToCard.setEnabled(true);
            holder.txt_VegPerKG.setText("0");
            holder.txt_VegPriceQuan.setText(lPrice + " x 0 =");
            holder.txt_VegTotalAmount.setText(""+lPrice);
        }
        holder.btn_VegAddToCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                   ConsumerOrderTagBean lTotal= (ConsumerOrderTagBean) v.getTag();
                String[] lAmount=lTotal.QuantityView.getText().toString().split("x");
                String lQuantity=lAmount[1].replace("=","");
                double lPrice=Double.parseDouble(lAmount[0])*Double.parseDouble(lQuantity);
                    if(lPrice>0) {
                        mConsumerHomeActivity.onSetTotalAmount("" + lPrice);
                        lTotal.VegQuantity = lQuantity;
                        ConsumerHomeActivity.mConsumerOrderList.add(lTotal);
                        mVegeDetailList.get(lTotal.SelectedPosition).isSelected = true;
                        mVegeDetailList.get(lTotal.SelectedPosition).custquanity = lQuantity;
                        mVegeDetailList.get(lTotal.SelectedPosition).custtotal = "" + lPrice;
                        v.setBackgroundResource(R.drawable.style_button_darkgray);
                        v.setEnabled(false);
                    }
            }catch (Exception e){}
            }
        });

        holder.btn_VegPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float lStock=Float.parseFloat("" + v.getTag());
                float lQuntity=Float.parseFloat("" + holder.txt_VegPerKG.getText());

                if(lQuntity<lStock){
                    if(lQuntity==0) {
                        lQuntity= (float) 0.25;
                    }else if(lQuntity==0.25){
                       lQuntity= (float) 0.50;
                    }else if(lQuntity==0.50){
                        lQuntity=1;
                    }else {
                        lQuntity++;
                    }
                    String lPricse=holder.txt_VegPrice.getText().toString();
                    float lTotal=Float.parseFloat(lPricse) * lQuntity;
                    if(lQuntity==0.25||lQuntity==0.50) {
                        holder.txt_VegPerKG.setText(""+lQuntity);
                        holder.txt_VegPriceQuan.setText(lPricse+" x "+lQuntity+"=");

                    }else {
                        String lQuant=String.format("%.0f",lQuntity);
                        holder.txt_VegPerKG.setText(lQuant);
                        holder.txt_VegPriceQuan.setText(lPricse+" x " + lQuant + "=");
                    }
                    holder.txt_VegTotalAmount.setText(""+lTotal);
                }
            }
        });

        holder.btn_VegNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float lQuntity=Float.parseFloat("" + holder.txt_VegPerKG.getText());
                if(lQuntity==1){
                    lQuntity=(float)0.50;
                }else if(lQuntity==0.50){
                    lQuntity=(float)0.25;
                }else if (lQuntity!=0.25&&lQuntity!=0){
                    lQuntity--;
                }
                String lPricse= holder.txt_VegPrice.getText().toString();
                float lTotal=Float.parseFloat(lPricse) * lQuntity;

                if(lQuntity==0.25||lQuntity==0.50) {
                    holder.txt_VegPerKG.setText(""+lQuntity);
                    holder.txt_VegPriceQuan.setText(lPricse+" x "+lQuntity+"=");

                }else {
                    String lQuant=String.format("%.0f",lQuntity);
                    holder.txt_VegPerKG.setText(lQuant);
                    holder.txt_VegPriceQuan.setText(lPricse+" x " + lQuant + "=");

                }
               holder.txt_VegTotalAmount.setText(""+lTotal);
            }
        });
 }

    @Override
    public int getItemCount() {
        return mVegeDetailList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public final View mView;
        public ConsumerVegtableDetailResponseModel.VegDetailWrapper mItem;
        public TextView txt_VegTitle,txt_VegQuantity,txt_VegPrice,txt_VegPerKG,txt_VegPriceQuan,txt_VegTotalAmount;
        public Button btn_VegAddToCard,btn_VegNegative,btn_VegPositive;
        public ImageView img_VegImage;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            txt_VegTitle=(TextView)view.findViewById(R.id.txt_cvegetitle);
            txt_VegQuantity=(TextView)view.findViewById(R.id.txt_cvegequantity);
            txt_VegPrice=(TextView)view.findViewById(R.id.txt_cvegeamount);
            txt_VegPerKG=(TextView)view.findViewById(R.id.txt_cvegechangequantity);
            txt_VegPriceQuan=(TextView)view.findViewById(R.id.txt_cvegselectquantity);
            txt_VegTotalAmount=(TextView)view.findViewById(R.id.txt_cvegetotalprice);

            btn_VegAddToCard=(Button)view.findViewById(R.id.btn_cvegeaddtocard);
            btn_VegPositive=(Button)view.findViewById(R.id.btn_cvegeaddquantity);
            btn_VegNegative=(Button)view.findViewById(R.id.btn_cvegeminusquantity);
            img_VegImage=(ImageView)view.findViewById(R.id.img_cvegetable);
        }

    }


}
