package com.codemaptechnology.gofresh.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.codemaptechnology.gofresh.utils.AlertDialogs;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.utils.NetworkConnectivity;

public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);


    }


    @Override
    protected void onResume() {
        super.onResume();

       new Thread(new Runnable() {
           @Override
           public void run() {
               try {
                   Thread.sleep(5000);
               } catch (InterruptedException e) {
                   e.printStackTrace();
               }finally {
                   if(NetworkConnectivity.isOnline()){
                   startActivity(new Intent(SplashScreenActivity.this, ConsumerHomeActivity.class));
                   finish();
               }else{
                       AlertDialogs.getInstance().onShowToastNotification(getResources().getString(R.string.error_netconnection));
                   }

               }
           }
       }).start();

    }
}
