package com.codemaptechnology.gofresh.javabean;

import android.widget.TextView;

/**
 * Created by satishmarkad on 16/02/16.
 */
public class ConsumerOrderTagBean {

    public TextView QuantityView;
    public String VegId;
    public String VegQuantity;
    public int SelectedPosition;
}
