package com.codemaptechnology.gofresh.http;



public interface ResponseListner {

	public void onGetResponse(String res);
}
