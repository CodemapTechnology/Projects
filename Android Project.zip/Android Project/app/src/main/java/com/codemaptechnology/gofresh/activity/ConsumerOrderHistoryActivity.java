package com.codemaptechnology.gofresh.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.codemaptechnology.gofresh.apimodel.ConsumerHistoryDetailResponseModel;
import com.codemaptechnology.gofresh.application.VegetableApplicationContext;
import com.codemaptechnology.gofresh.http.JsonRequestClass;
import com.codemaptechnology.gofresh.http.ResponseListner;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.adapter.ConsumerOrderHistoryListAdapter;
import com.codemaptechnology.gofresh.apimodel.RequestModel;
import com.codemaptechnology.gofresh.javabean.ConsumerOrderTagBean;
import com.codemaptechnology.gofresh.utils.Constant;
import com.google.gson.Gson;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ConsumerOrderHistoryActivity extends AppCompatActivity implements ResponseListner {

    @Bind(R.id.recyclerview_orderlist)
    RecyclerView recyclerView_OrderList;
    public  ArrayList<ConsumerOrderTagBean> mConsumerOrderList;
    @Bind(R.id.txt_writeushelptitle)
    TextView txt_Title;


    protected void onCreate(Bundle onSaveInstanceState){
        super.onCreate(onSaveInstanceState);
        setContentView(R.layout.activity_orderhistory);
        ButterKnife.bind(this);
        init();

    }

    private void init() {
        txt_Title.setVisibility(View.VISIBLE);
        txt_Title.setTextColor(Color.BLACK);
        txt_Title.setText("History");

        mConsumerOrderList=new ArrayList<ConsumerOrderTagBean>();
        recyclerView_OrderList.setHasFixedSize(true);
        recyclerView_OrderList.setLayoutManager(new LinearLayoutManager(ConsumerOrderHistoryActivity.this));

        // recyclerView_OrderList.bringToFront()
        onSendRequestToServer();
    }

    private void onSendRequestToServer() {
        RequestModel lRequest=new RequestModel();
        lRequest.setAPImethod(Constant.GETORDERHISTORY);
        lRequest.setRequestParamerter("isuser", VegetableApplicationContext.onGETUserEmail());
        new JsonRequestClass(this).onJsonObjReq(this, lRequest);
    }


    @OnClick(R.id.txt_writeusback)
    public void txt_writeusback(View v){
        finish();
    }

    @Override
    public void onGetResponse(String res) {

       // Log.e("Response", res);

        ConsumerHistoryDetailResponseModel lResponse=ConsumerHistoryDetailResponseModel.onGetInsatance();

        lResponse=new Gson().fromJson(res,lResponse.getClass());

            onSetAdapters(lResponse.orderdesc);
           lResponse.onSetResponseObject(lResponse);

    }


    private void onSetAdapters(ArrayList<ConsumerHistoryDetailResponseModel.Orderdesc> mVegeDetailList) {

        ConsumerOrderHistoryListAdapter mAdapter=new ConsumerOrderHistoryListAdapter(ConsumerOrderHistoryActivity.this,mVegeDetailList);
        recyclerView_OrderList.setAdapter(mAdapter);


    }



}
