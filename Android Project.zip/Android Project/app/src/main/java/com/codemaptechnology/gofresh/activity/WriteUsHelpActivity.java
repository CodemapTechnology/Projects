package com.codemaptechnology.gofresh.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.codemaptechnology.gofresh.apimodel.RequestModel;
import com.codemaptechnology.gofresh.apimodel.ResponseModel;
import com.codemaptechnology.gofresh.application.VegetableApplicationContext;
import com.codemaptechnology.gofresh.http.JsonRequestClass;
import com.codemaptechnology.gofresh.http.ResponseListner;
import com.codemaptechnology.gofresh.utils.AlertDialogs;
import com.codemaptechnology.gofresh.utils.Constant;
import com.codemaptechnology.gofresh.utils.NetworkConnectivity;
import com.codemaptechnology.gofresh.R;
import com.google.gson.Gson;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class WriteUsHelpActivity extends AppCompatActivity implements ResponseListner {

    @Bind(R.id.webview_help)
    WebView mWebViewHelp;
    @Bind(R.id.btn_writeussubmit)
    Button btn_Submit;
    @Bind(R.id.edit_vegetalbeappquery)
    EditText edt_UserQuery;
    @Bind(R.id.txt_writeushelptitle)
    TextView txt_Title;

    private AlertDialogs mAlertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_writeushelp);
        ButterKnife.bind(this);
        init();
    }

    private void init() {

        mAlertDialog=AlertDialogs.getInstance();

            if (getIntent().getBooleanExtra("ISHELP", false)) {
                mAlertDialog.onShowProgressDialog(this,true);
                mWebViewHelp.setVisibility(View.VISIBLE);
                btn_Submit.setVisibility(View.GONE);
                edt_UserQuery.setVisibility(View.GONE);
                txt_Title.setText("Help");
                mWebViewHelp.getSettings().setJavaScriptEnabled(true); // enable javascript

                final Activity activity = this;

                mWebViewHelp.setWebViewClient(new WebViewClient() {
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        view.loadUrl(url);
                        return true;
                    }

                    public void onPageFinished(WebView view, String url) {
                            mAlertDialog.onShowProgressDialog(WriteUsHelpActivity.this, false);

                    }

                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                         mAlertDialog.onShowToastNotification(getResources().getString(R.string.error_netconnection));
                    }
                });

                mWebViewHelp .loadUrl("http://gofresh.online/special.html");
            }

        btn_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(NetworkConnectivity.isOnline()){
                String lMsg=edt_UserQuery.getText().toString();
                String lUser= VegetableApplicationContext.onGETUserEmail();
                if(lMsg.length()>0){
                    onHideSoftKeyboardDevice();
                    RequestModel lRequest=new RequestModel();
                    lRequest.setAPImethod(Constant.SETMESSAGE);
                    lRequest.setRequestParamerter("isuser",lUser);
                    lRequest.setRequestParamerter("msg",lMsg);
                    new JsonRequestClass(WriteUsHelpActivity.this).onJsonObjReq(WriteUsHelpActivity.this, lRequest);
                }
            }else{
                    mAlertDialog.onShowToastNotification(getResources().getString(R.string.error_netconnection));
                }
            }
        });
    }

    private void onHideSoftKeyboardDevice() {

        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }


    @OnClick(R.id.txt_writeusback)
    public void txt_writeusback(View v){
        finish();
    }

    @Override
    public void onGetResponse(String res) {
        ResponseModel lResponse=new ResponseModel();
        lResponse=new Gson().fromJson(res,lResponse.getClass());
        if(lResponse.status!=200){
            mAlertDialog.onShowToastNotification(lResponse.msg);
        }else{
            mAlertDialog.onShowToastNotification(lResponse.msg);
            edt_UserQuery.setText("");
        }
    }
}
