package com.codemaptechnology.gofresh.apimodel;

import java.util.HashMap;

/**
 * Created by satishmarkad on 22/01/16.
 */
public class RequestModel {

    private String APImethod;

    private HashMap<String,String> requestParamerter=new HashMap<String,String>();

    public String getAPImethod() {
        return APImethod;
    }


    public void setAPImethod(String APImethod) {
        this.APImethod = APImethod;
    }

    public HashMap<String, String> getRequestParamerter() {
        return requestParamerter;
    }

    public void setRequestParamerter(String key, String value) {

        requestParamerter.put(key,value);
    }


}
