package com.codemaptechnology.gofresh.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.codemaptechnology.gofresh.apimodel.ResponseModel;
import com.codemaptechnology.gofresh.application.VegetableApplicationContext;
import com.codemaptechnology.gofresh.http.JsonRequestClass;
import com.codemaptechnology.gofresh.http.ResponseListner;
import com.codemaptechnology.gofresh.utils.AlertDialogs;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.apimodel.PlaceOrderRequestModel;
import com.codemaptechnology.gofresh.apimodel.RequestModel;
import com.codemaptechnology.gofresh.javabean.ConsumerOrderTagBean;
import com.codemaptechnology.gofresh.utils.Constant;
import com.codemaptechnology.gofresh.utils.NetworkConnectivity;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.Date;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ConsumerOrderActivity extends AppCompatActivity implements ResponseListner {

    @Bind(R.id.txt_writeushelptitle)
    TextView txt_Title;
    @Bind(R.id.btn_placeordersubmit)
    Button btn_PlaceOrder;
    @Bind(R.id.txt_placeordapplay)
    TextView txt_Applay;
    @Bind(R.id.txt_ordersubtotal)
     TextView txt_SubTotal;
    @Bind(R.id.txt_placeordtotal)
    TextView txt_GrandTotal;



    @Bind(R.id.edt_placeordaddress)
    EditText edt_Address;
    @Bind(R.id.edt_placeordemail)
    EditText edt_Email;
    @Bind(R.id.edt_placeordnumber)
    EditText edt_MobileNum;
    @Bind(R.id.edt_placeordpromo)
    EditText edt_PromoCode;
    private double mGrandTotal;


    private AlertDialogs mAlertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placeorder);
        ButterKnife.bind(this);
        init();
    }

    private void init() {

        mAlertDialog=AlertDialogs.getInstance();
        txt_Title.setText("Order");
        edt_Address.setText(VegetableApplicationContext.onGETUserAddress());
        edt_Email.setText(VegetableApplicationContext.onGETUserEmail());
        edt_MobileNum.setText(VegetableApplicationContext.onGETUserNumber());
        //Set Total and Grand Total
        mGrandTotal=getIntent().getDoubleExtra("TOTALAMOUNT",0.00);

        txt_SubTotal.setText("" + mGrandTotal);
        txt_GrandTotal.setText("" + mGrandTotal);


        btn_PlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (NetworkConnectivity.isOnline()) {
                    String address = edt_Address.getText().toString();
                    String email = edt_Email.getText().toString();
                    String number = edt_MobileNum.getText().toString();


                    if (address.length() > 0 && isValidEmail(email) && number.length() == 10) {

                        PlaceOrderRequestModel lRequest = new PlaceOrderRequestModel();
                        lRequest.setAPImethod(Constant.SETPLACEORDER);
                        lRequest.setOrddatetime(address);
                        lRequest.setConphone(number);
                        lRequest.setConemail(email);
                        String currentDateandTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
                        lRequest.setOrddatetime(currentDateandTime);
                        lRequest.setOrdstatus("Ordered");

                        for (int i = 0; i < ConsumerHomeActivity.mConsumerOrderList.size(); i++) {

                            ConsumerOrderTagBean lObj = ConsumerHomeActivity.mConsumerOrderList.get(i);
                            lRequest.setOrderdesc(lObj.VegId, lObj.VegQuantity);

                        }
                        Log.e("RESPONCE", "" + new Gson().toJson(lRequest));
                        new JsonRequestClass(ConsumerOrderActivity.this).onJsonObjReq(ConsumerOrderActivity.this, lRequest);
                        VegetableApplicationContext.onSaveUserDetail(address, email, number);

                    } else {
                        AlertDialogs.getInstance().onShowToastNotification(getString(R.string.error_userinfo));
                    }
                } else {
                    mAlertDialog.onShowToastNotification(getResources().getString(R.string.error_netconnection));
                }
            }
        });

        txt_Applay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkConnectivity.isOnline()) {

                    String lPromo = edt_PromoCode.getText().toString();
                    String lEmail = VegetableApplicationContext.onGETUserEmail();
                    if (lEmail.length() > 0 && lPromo.length() > 0) {
                        RequestModel lRequest = new RequestModel();
                        lRequest.setAPImethod(Constant.GETPROMODISCOUNT);
                        lRequest.setRequestParamerter("isuser", lEmail);
                        lRequest.setRequestParamerter("mycode", lPromo);
                        new JsonRequestClass(ConsumerOrderActivity.this).onJsonObjReq(ConsumerOrderActivity.this, lRequest);
                        Log.e("RESPONCE", "" + new Gson().toJson(lRequest));
                    }
                } else {
                    mAlertDialog.onShowToastNotification(getResources().getString(R.string.error_netconnection));
                }

            }
        });
    }

    @OnClick(R.id.txt_writeusback)
    public void txt_writeusback(View v){
        ConsumerHomeActivity.mConsumerOrderList.clear();
        finish();
    }



    private boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    @Override
    public void onGetResponse(String res) {

        Log.e("Response",res);

        ResponseModel lResponse=new ResponseModel();
        lResponse=new Gson().fromJson(res,lResponse.getClass());
        if(lResponse.status!=200){
           mAlertDialog.onShowToastNotification(lResponse.msg);
        }else{

            if(lResponse.msg.equalsIgnoreCase("Promocode applied successfully")) {
                mAlertDialog.onShowToastNotification(lResponse.msg);
                double lTotal = Double.parseDouble(txt_GrandTotal.getText().toString()) - Double.parseDouble("" + lResponse.discount);
                txt_GrandTotal.setText("" + lTotal);
                edt_PromoCode.setText("");

            }else{

                Toast toast = Toast.makeText(ConsumerOrderActivity.this,lResponse.msg+" your order id is "+lResponse.orderid, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
               // mAlertDialog.onShowToastNotification(lResponse.msg+" your order id is "+lResponse.orderid);
                ConsumerHomeActivity.mConsumerOrderList.clear();
                finish();
            }
        }


    }
}
