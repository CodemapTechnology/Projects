package com.codemaptechnology.gofresh.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.codemaptechnology.gofresh.adapter.ConsumerOrderDetailHistoryListAdapter;
import com.codemaptechnology.gofresh.apimodel.ConsumerHistoryDetailResponseModel;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.javabean.ConsumerOrderTagBean;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ConsumerOrderDetailHistoryActivity extends AppCompatActivity {

    @Bind(R.id.recyclerview_orderlist)
    RecyclerView recyclerView_OrderList;
    public  ArrayList<ConsumerOrderTagBean> mConsumerOrderList;
    @Bind(R.id.txt_writeushelptitle)
    TextView txt_Title;


    protected void onCreate(Bundle onSaveInstanceState){
        super.onCreate(onSaveInstanceState);
        setContentView(R.layout.activity_orderhistory);
        ButterKnife.bind(this);
        init();

    }

    private void init() {
        txt_Title.setVisibility(View.VISIBLE);
        txt_Title.setTextColor(Color.BLACK);
        txt_Title.setText("History Detail");

        mConsumerOrderList=new ArrayList<ConsumerOrderTagBean>();
        recyclerView_OrderList.setHasFixedSize(true);
        recyclerView_OrderList.setLayoutManager(new LinearLayoutManager(ConsumerOrderDetailHistoryActivity.this));
        ConsumerHistoryDetailResponseModel lResponse=ConsumerHistoryDetailResponseModel.onGetInsatance();
        int postion=getIntent().getIntExtra("POSITION",0);
        if(lResponse!=null) {
            onSetAdapters(lResponse.orderdesc.get(postion).orddetails);
        }
    }



    @OnClick(R.id.txt_writeusback)
    public void txt_writeusback(View v){
        finish();
    }




    private void onSetAdapters(ArrayList<ConsumerHistoryDetailResponseModel.Orddetails> mVegeDetailList) {

        ConsumerOrderDetailHistoryListAdapter mAdapter=new ConsumerOrderDetailHistoryListAdapter(ConsumerOrderDetailHistoryActivity.this,mVegeDetailList);
        recyclerView_OrderList.setAdapter(mAdapter);


    }



}
