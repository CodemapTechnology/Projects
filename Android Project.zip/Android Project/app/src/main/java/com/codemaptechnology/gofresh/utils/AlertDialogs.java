package com.codemaptechnology.gofresh.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.codemaptechnology.gofresh.application.VegetableApplicationContext;


public class AlertDialogs {

	private ProgressDialog mDialog;
	private static AlertDialogs mInstance;

	public static AlertDialogs getInstance() {
		//TODO Get Single Instance

		if (mInstance == null) {
			mInstance = new AlertDialogs();
		}
		return mInstance;
	}

	public void onShowProgressDialog(FragmentActivity activity,
			boolean isShow) {
		// TODO Show ProgressDialog

		try {
			if (isShow) {
				mDialog=ProgressDialog.show(activity,"","Loading...",true);
			mDialog.show();
			} else {
				if (mDialog.isShowing())
					mDialog.dismiss();
			}
		} catch (Exception e) {

		}
	}


   public void onShowToastNotification(String msg){

	   Toast.makeText(VegetableApplicationContext.getContext(),msg,Toast.LENGTH_LONG).show();
   }

	public void setupUI(final FragmentActivity lActivity, View view,
			final EditText lEditText, final ImageView lMagGlass) {

		// Set up touch listener for non-text box views to hide keyboard.
		if (!(view instanceof EditText)) {

			view.setOnTouchListener(new OnTouchListener() {

				@Override
				public boolean onTouch(View arg0, MotionEvent arg1) {
					onHideKeyBoard(lActivity, lEditText, lMagGlass);
					return false;
				}
			});
		}

		// If a layout container, iterate over children and seed recursion.
		if (view instanceof ViewGroup) {

			for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {

				View innerView = ((ViewGroup) view).getChildAt(i);

				setupUI(lActivity, innerView, lEditText, lMagGlass);
			}
		}
	}

	private void onHideKeyBoard(FragmentActivity mActivity, EditText lEditText,
			ImageView lMagGlass) {
		final InputMethodManager imm = (InputMethodManager) mActivity
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(lEditText.getWindowToken(), 0);

		lEditText.clearFocus();
		if (lMagGlass != null) {
			if (TextUtils.isEmpty(lEditText.getText().toString())) {
				lMagGlass.setVisibility(View.VISIBLE);
			} else {
				lMagGlass.setVisibility(View.GONE);
			}

		}

	}

//	public void onCustomAlertViewDialog(Activity activity){
//
//		// Create custom dialog object
//		final Dialog lDialog = new Dialog(activity, R.style.DialogTheme);
//		// Include dialog.xml file
//		lDialog.setContentView(R.layout.alertdialog_customsenderview);
//		// Set dialog title
//		lDialog.getWindow().setBackgroundDrawableResource(R.color.colordialog);
//
//
//		lDialog.show();
//
//		Button lBtn_Close = (Button) lDialog.findViewById(R.id.btn_viewclose);
//		TextView lTxt_SenderTotal=(TextView)lDialog.findViewById(R.id.txt_viewtotal);
//		//lTxt_SenderTotal.setText(Html.fromHtml(HomeActivity.onTextColorChange()));
//		// if decline button is clicked, close the custom dialog
//
//		lBtn_Close.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				lDialog.dismiss();
//			}
//		});
//	}

}
