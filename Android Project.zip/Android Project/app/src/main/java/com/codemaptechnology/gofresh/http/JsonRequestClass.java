package com.codemaptechnology.gofresh.http;

import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;

import com.codemaptechnology.gofresh.utils.AlertDialogs;
import com.codemaptechnology.gofresh.R;
import com.codemaptechnology.gofresh.apimodel.PlaceOrderRequestModel;
import com.codemaptechnology.gofresh.apimodel.RequestModel;
import com.codemaptechnology.gofresh.utils.NetworkConnectivity;



public class JsonRequestClass
{

	private AlertDialogs mAlertMyCar;
	private ResponseListner mListner;
	private RequestModel mRequestModel=null;
	private PlaceOrderRequestModel mPlaceOrderRequest=null;
    private FragmentActivity mFragment;
	public JsonRequestClass(ResponseListner listner)
	{
		// TODO Auto-generated constructor stub

		
		mListner = listner;
		mAlertMyCar = AlertDialogs.getInstance();
		
	}

	

	public void onJsonObjReq(FragmentActivity frag, RequestModel jObject)
	{
		if(NetworkConnectivity.isOnline()){
		   mFragment=frag;
		   mRequestModel =jObject;
		   new RequestJson().execute();
		}else{

          mAlertMyCar.onShowToastNotification(frag.getApplication().getResources().getString(R.string.error_netconnection));
		}
	}

	public void onJsonObjReq(FragmentActivity frag, PlaceOrderRequestModel jObject)
	{
		if(NetworkConnectivity.isOnline()){
			mFragment=frag;
			mPlaceOrderRequest =jObject;
			new RequestJson().execute();
		}else{

			mAlertMyCar.onShowToastNotification(frag.getApplication().getResources().getString(R.string.error_netconnection));
		}
	}

	public class RequestJson extends AsyncTask<String, String, String>
	{
		@Override
		protected void onPreExecute()
		{
			// TODO Auto-generated method stub
			super.onPreExecute();
			 mAlertMyCar.onShowProgressDialog(mFragment,true);

		}
		
		@Override
		protected String doInBackground(String... params)
		{
			// TODO Auto-generated method stub
			String lResponse ;
				lResponse = HttpRequestResponse.onHTTPRquest(mRequestModel,mPlaceOrderRequest);

			///try{Thread.sleep(100000);}catch(Exception e){}
			return lResponse;
		}

		

		@Override
		protected void onPostExecute(String result)
		{
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			      mAlertMyCar.onShowProgressDialog(mFragment,false);
			try
			{

				if (result!=null)
				{
					mListner.onGetResponse(result);
				} else
				{
					mAlertMyCar.onShowToastNotification("Please try later Server not responding ");
				}
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}

	}

}
