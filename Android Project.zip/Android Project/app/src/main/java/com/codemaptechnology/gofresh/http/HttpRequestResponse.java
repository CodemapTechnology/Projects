package com.codemaptechnology.gofresh.http;


import android.util.Log;

import com.codemaptechnology.gofresh.apimodel.PlaceOrderRequestModel;
import com.codemaptechnology.gofresh.apimodel.RequestModel;
import com.codemaptechnology.gofresh.utils.Constant;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HttpRequestResponse {

    private final static int CONNECTION_TIMEOUT = 180000;

    public static String onHTTPRquest(RequestModel requestModel,PlaceOrderRequestModel requestPlaceOrder) {
        StringBuilder response = new StringBuilder();;

        HttpURLConnection urlConnection = null;
        try {
            // create connection
            URL urlToRequest ;
            if(requestModel!=null) {
                urlToRequest = new URL(Constant.SERVER_URL + requestModel.getAPImethod());
            }else{
                urlToRequest = new URL(Constant.SERVER_URL + requestPlaceOrder.getAPImethod());

            }
            urlConnection = (HttpURLConnection) urlToRequest.openConnection();
            urlConnection.setConnectTimeout(CONNECTION_TIMEOUT);

            // handle POST parameters
            if(requestModel!=null) {
                if (!requestModel.getRequestParamerter().isEmpty()) {
                    urlConnection.setDoOutput(true);
                    urlConnection.setUseCaches(false);
                    urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    urlConnection.setRequestMethod("POST");
                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(getPostDataString(requestModel.getRequestParamerter()));

                    writer.flush();
                    writer.close();
                    os.close();
                    urlConnection.connect();
                } else {

                    urlConnection.setRequestMethod("GET");
                }
            }else{
                urlConnection.setDoOutput(true);
                urlConnection.setUseCaches(false);
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestMethod("POST");
                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
               String lResult= new Gson().toJson(requestPlaceOrder);//getPlaceDataString(requestPlaceOrder.getOrderdesc());
                Log.e("Result",lResult);
                writer.write(lResult);

                writer.flush();
                writer.close();
                os.close();
                urlConnection.connect();
            }
            // handle issues
            int statusCode = urlConnection.getResponseCode();
            if (statusCode == HttpURLConnection.HTTP_OK||statusCode==HttpURLConnection.HTTP_CREATED) {
                BufferedReader lBufferReader=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                String inputLine;

                while ((inputLine = lBufferReader.readLine()) != null) {
                    response.append(inputLine);
                }
                lBufferReader.close();

            }


        } catch (MalformedURLException e) {
            // handle invalid URL
        } catch (SocketTimeoutException e) {
            // hadle timeout
        } catch (IOException e) {
            // handle I/0
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        return "" + response.toString();
    }


    private static String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for(Map.Entry<String, String> entry : params.entrySet()){
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

    private static String getPlaceDataString( HashMap<String,ArrayList> lhash) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        ArrayList<HashMap<String,String>> orderList=lhash.get("orderdesc");
        for(int i=0;i<orderList.size();i++){
            HashMap<String, String> params=orderList.get(i);
        for(Map.Entry<String, String> entry : params.entrySet()){
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }}

        return result.toString();
    }
}