package com.codemaptechnology.gofresh.apimodel;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by satishmarkad on 22/01/16.
 */
public class PlaceOrderRequestModel {


    private String APImethod;

    public String getConaddr() {
        return conaddr;
    }

    public void setConaddr(String conaddr) {
        this.conaddr = conaddr;
    }

    private String conaddr;

    public String getConphone() {
        return conphone;
    }

    public void setConphone(String conphone) {
        this.conphone = conphone;
    }

    public String getConemail() {
        return conemail;
    }

    public void setConemail(String conemail) {
        this.conemail = conemail;
    }

    public String getOrddatetime() {
        return orddatetime;
    }

    public void setOrddatetime(String orddatetime) {
        this.orddatetime = orddatetime;
    }

    public String getOrdstatus() {
        return ordstatus;
    }

    public void setOrdstatus(String ordstatus) {
        this.ordstatus = ordstatus;
    }

    private String conphone;
    private String conemail;
    private String orddatetime;
    private String ordstatus;

    public String getAPImethod() {
        return APImethod;
    }


    public void setAPImethod(String APImethod) {
        this.APImethod = APImethod;
    }



    private ArrayList<HashMap<String,String>> orderdesc=new ArrayList<HashMap<String, String>>();

   public  void setOrderdesc(String id,String qun){

        HashMap<String,String> lOrder=new HashMap<String,String>();
        lOrder.put("ordvegid",id);
        lOrder.put("ordqty",qun);
        orderdesc.add(lOrder);
    }

    public HashMap<String,ArrayList> getOrderdesc(){
        HashMap<String,ArrayList>lList=new HashMap<String,ArrayList>();
        lList.put("orderdesc",orderdesc);
        return  lList;
    }
}
