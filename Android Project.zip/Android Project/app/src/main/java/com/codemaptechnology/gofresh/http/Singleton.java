package com.codemaptechnology.gofresh.http;


import com.google.gson.Gson;

public class Singleton {

	private static Gson gsonInstance;

	private Singleton() {
	}

	public static Gson getGsonInstance() {

		if (gsonInstance == null) {

			gsonInstance = new Gson();
		}

		return gsonInstance;
	}

}