package com.codemaptechnology.gofresh.apimodel;

/**
 * Created by satishmarkad on 12/04/16.
 */
public class ConsumerOrderDetailResponseModel {


}
