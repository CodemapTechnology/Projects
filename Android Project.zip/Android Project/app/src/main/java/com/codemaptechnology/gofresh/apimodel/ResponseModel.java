package com.codemaptechnology.gofresh.apimodel;

/**
 * Created by satishmarkad on 22/01/16.
 */
public  class ResponseModel {

    public int status;
    public String discount;
    public String msg;
    public String orderid;
}
